<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    
</head>
<body>

<div style="font-family: 'Poppins', sans-serif;">
    Hi Osemeilu Itua,
    <br>
    Thank you for creating an account with us at Workpro. Verify your account to complete the registration!
    <br>
    Please click on the link below or copy Gbenga it into the address bar of your browser to confirm your email address:
    <br>
    <b>4567</b>

    <br/>
</div>

</body>
</html>
